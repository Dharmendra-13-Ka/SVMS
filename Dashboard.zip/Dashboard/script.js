console.log("SVMS Started");

const API = "http://192.168.56.218:5001/data";

function searchDevice() {

    fetch(API)
    .then(res => res.json())
    .then(data => {

        document.getElementById("voltage").innerHTML =
        "Current Voltage : " + data.voltage + " V";

        document.getElementById("minvoltage").innerHTML =
        "Minimum Voltage : " + data.min_voltage + " V";

        document.getElementById("maxvoltage").innerHTML =
        "Maximum Voltage : " + data.max_voltage + " V";

        document.getElementById("current").innerHTML =
        "Current : " + data.current + " A";

        document.getElementById("mincurrent").innerHTML =
        "Minimum Current : " + data.min_current + " A";

        document.getElementById("maxcurrent").innerHTML =
        "Maximum Current : " + data.max_current + " A";

        document.getElementById("power").innerHTML =
        "Power : " + data.power + " W";

        document.getElementById("relay").innerHTML =
        "Relay Status : " + data.relay;

        document.getElementById("charger").innerHTML =
        "Charger Status : " + data.charger;

        document.getElementById("alarm").innerHTML =
        "Alarm : " + data.alarm;

    })
    .catch(err => console.log(err));

}

function relayOn()
{
    alert("Relay ON");
}

function relayOff()
{
    alert("Relay OFF");
}

setInterval(searchDevice,1000);