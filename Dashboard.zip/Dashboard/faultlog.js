async function loadFaultLog() {

    try {

        let device = document.getElementById("faultDeviceId").value;

const response = await fetch(
    "http://192.168.56.218:5001/faultlog"
);

        const faults = await response.json();

        const table = document.getElementById("faultTable");

        while (table.rows.length > 1) {
            table.deleteRow(1);
        }

        faults.forEach(function(item){

            let row = table.insertRow();

            row.insertCell(0).innerHTML = "-";
            row.insertCell(1).innerHTML = "-";
            row.insertCell(2).innerHTML = item.voltage + " V";
            row.insertCell(3).innerHTML = item.current + " A";
            row.insertCell(4).innerHTML = item.power + " W";
            row.insertCell(5).innerHTML = item.alarm;
            row.insertCell(6).innerHTML = "OFF";

        });

    }

    catch(error){

        console.log(error);

    }

}



