function login() {

    let username = document.getElementById("username").value;

    let password = document.getElementById("password").value;

    fetch("http://localhost:5000/login", {

        method: "POST",

        headers: {

            "Content-Type": "application/json"

        },

        body: JSON.stringify({

            username: username,

            password: password

        })

    })

    .then(response => response.json())

    .then(data => {

        if (data.status == "success") {

            alert("Login Successful");

            window.location.href = "index.html";

        }

        else {

            document.getElementById("message").innerHTML =
            "Invalid Username or Password";

        }

    })

    .catch(error => {

        console.log(error);

    });

}